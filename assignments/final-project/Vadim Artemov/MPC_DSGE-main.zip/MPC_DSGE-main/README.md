# MPC_DSGE
MPC in DSGE

This repository contains notebook with implementation of DGSE model environment and some control methods to it. 

Just download the notebook and run it, all the results will be done for you automatically, all the plots and loss values will be calculated automatically
